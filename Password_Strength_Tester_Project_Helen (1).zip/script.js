
const password = document.getElementById('password');
const strengthBar = document.getElementById('strengthBar');
const feedback = document.getElementById('feedback');

password.addEventListener('input', () => {
  const val = password.value;
  let strength = 0;

  if (val.length > 6) strength++;
  if (val.match(/[A-Z]/)) strength++;
  if (val.match(/[0-9]/)) strength++;
  if (val.match(/[@$!%*?&]/)) strength++;

  switch (strength) {
    case 0:
      strengthBar.style.backgroundColor = "#ccc";
      feedback.textContent = "";
      break;
    case 1:
      strengthBar.style.backgroundColor = "#ff4d4d";
      feedback.textContent = "Weak";
      feedback.style.color = "#ff4d4d";
      break;
    case 2:
      strengthBar.style.backgroundColor = "#ffa500";
      feedback.textContent = "Fair";
      feedback.style.color = "#ffa500";
      break;
    case 3:
      strengthBar.style.backgroundColor = "#ffff66";
      feedback.textContent = "Good";
      feedback.style.color = "#ffff66";
      break;
    case 4:
      strengthBar.style.backgroundColor = "#4CAF50";
      feedback.textContent = "Strong";
      feedback.style.color = "#4CAF50";
      break;
  }
});
